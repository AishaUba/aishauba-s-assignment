COLOR CODES FOR NIGHTOWL TECHNOLOGY
primary color: #03a9f4
font color: #747a87
link color: #
footer color: #333333

FLIP BOXES
1. Green: #3fc7b0
2. Orange: #f67a68
3. Blue: #339bc2
4. Red: #c83f43
5. Purple: #a96eb7
6. Brown: #be8864


ICONS

font awesome icons

TYPOGRAPHY

font name: Agency FB
font size: 18px
Line Height 30px
letter spacing: 0


